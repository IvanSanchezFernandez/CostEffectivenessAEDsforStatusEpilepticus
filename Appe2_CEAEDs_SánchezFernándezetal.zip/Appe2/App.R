####Copyleft Ivan Sanchez Fernandez 2018

# ui.R
library(shiny)
library(ggplot2)
library(plotly)
# App appearance
ui <- fluidPage(
  # Beginning of fluidPage
  
  tags$br(),
  tags$strong("COST-EFFECTIVENESS OF ANTIEPILEPTIC DRUGS (AEDs) FOR STATUS EPILEPTICUS"),
  tags$br(),
  tags$br(),
  tags$strong("Explore how different inputs modify cost-effectiveness"),
  tags$br(),
  tags$header("Remember to enter appropriate inputs into the model: proportions should go from 0 to 1, the cost of No AED should be 0, and the rest of the costs cannot be negative. With inappropriate inputs the model will return inappropriate outputs or errors"),
  tags$br(),
  
  sidebarLayout(
    # Beginning of sidebarLayout
    
    sidebarPanel(
      # Beginning of sidebarPanel
      
  fluidRow(

    column(6,
           # Title
           tags$br(),
           tags$br(),
           tags$strong("INPUT"),    
           tags$br(),
           tags$br(),
           tags$br(),
           tags$br(),
           tags$strong("COST ($)"),
           tags$br(),
           tags$br(),
           tags$br(),
           tags$br(),
  ## INPUTS
  # Input cost of rescue medications
  textInput(inputId = "c.NoAED",
               label = "No AED",
               value = 0,
            width = 150),
  textInput(inputId = "c.PHT",
               label = "IV Phenytoin",
               value = 37.38,
            width = 150),  
  textInput(inputId = "c.PB",
               label = "IV Phenobarbital",
               value = 96.25,
            width = 150),    
  textInput(inputId = "c.VPA",
               label = "IV Valproate",
               value = 20,
            width = 150),   
  textInput(inputId = "c.LEV",
               label = "IV Levetiracetam",
               value = 11.5,
            width = 150),
  textInput(inputId = "c.LAC",
            label = "IV Lacosamide",
            value = 127.2,
            width = 150)    
  ), 

  column(6, 
         tags$br(),
         tags$br(),   
         tags$br(),
         tags$br(),
         tags$br(),
         tags$br(),
         tags$strong("SEIZURE STOPPED"),
         tags$br(),
         tags$strong("(SS)"),
         tags$br(),
         tags$br(),
         tags$br(),
  # Input probabilities into the model
  textInput(inputId = "p.NoAEDSS",
               label = "No AED",
               value = 0,
            width = 150),  
  textInput(inputId = "p.PHTSS",
               label = "IV Phenytoin",
               value = 0.53,
            width = 150),   
  textInput(inputId = "p.PBSS",
               label = "IV Phenobarbital",
               value = 0.8,
            width = 150),   
  textInput(inputId = "p.VPASS",
               label = "IV Valproate",
               value = 0.71,
            width = 150), 
  textInput(inputId = "p.LEVSS",
               label = "IV Levetiracetam",
               value = 0.62,
            width = 150),
  textInput(inputId = "p.LACSS",
            label = "IV Lacosamide",
            value = 0.66,
            width = 150)  
  )
  ),img(src = 'Figuretree.png', height = "100%", width = "100%")
  
  # End of sidebarPanel
  ), 
  
  mainPanel(
    # Beginning of mainPanel
    
  ## OUTPUTS  

  column(12, offset = 1,
         # ICER table
         tags$br(),
         tags$br(),
         tags$strong("OUTPUT"),
         tags$br(),
         tags$br(),
         tags$strong("Cost-effectiveness referenced to common baseline of no AED:"),
         textOutput("ICERbaseline"),
         tags$header("For illustrative purposes only."),
         tags$header("The most common measure of cost-effectiveness is the ICER referenced to the next most cost-effective alternative as presented in the Cost-Effectiveness Table."),
         
         
         tags$br(),
         tags$br(),
         tags$strong("COST-EFFECTIVENESS TABLE"),
         tags$br(),
         tags$br(),  
         tableOutput("ICER"),
         tags$strong("*Strategies that are not cost-effective dissappear from the table"),
         tags$br(),
         tags$strong("Legend: IE: incremental effectiveness. IC: incremental cost. ICER: incremental cost-effectiveness ratio"),
         
         
         #CE graph
         tags$br(),
         tags$br(),
         tags$br(),
         tags$br(),
         tags$strong("COST-EFFECTIVENESS PLOT"),
         tags$br(),  
         tags$br(), 
         plotlyOutput("plotCE", width = 800, height = 500),
         tags$br(),
         tags$strong("Legend: NoAED: No AED. PHT: IV Phenytoin. PB: IV Phenobarbital. VPA: IV Valproate. LEV: IV Levetiracetam. LAC: IV Lacosamide."))

  # End of mainPanel
  )

# End of sidebarLayout
),
tags$br(),
tags$br(),
tags$header("Ivan Sanchez Fernandez 2018. This work is copylefted under a General Public Licence (GPL)."),
tags$header("Users are fee to run, study, and modify this software and to share and distribute original or modified versions of this software.")

# End of fluidPage
)







# server.R
library(shiny)
library(ggplot2)
library(plotly)

server <- function(input, output) {
  
  
  
  # ICER REFERENCED TO COMMON BASELINE
  
  output$ICERbaseline <- renderText({
    
    # Define the values based on the inputs
    p.PHTSS <- as.numeric(input$p.PHTSS)
    p.PBSS <- as.numeric(input$p.PBSS)
    p.VPASS <- as.numeric(input$p.VPASS)
    p.LEVSS <- as.numeric(input$p.LEVSS)
    p.LACSS <- as.numeric(input$p.LACSS)
    
    
    c.PHT <- as.numeric(input$c.PHT)
    c.PB <- as.numeric(input$c.PB)
    c.VPA <- as.numeric(input$c.VPA)
    c.LEV <- as.numeric(input$c.LEV)
    c.LAC <- as.numeric(input$c.LAC)
    
    
    # Define the cost-effectiveness referenced to common baseline of no AED
    CEPHT <- c.PHT / p.PHTSS
    CEPB <- c.PB / p.PBSS
    CEVPA <- c.VPA / p.VPASS
    CELEV <- c.LEV / p.LEVSS
    CELAC <- c.LAC / p.LACSS
    
    # Save values into a dataframe
    CEbaselinevector <- c(CEPHT, CEPB, CEVPA, CELEV, CELAC)
    CEbaselinenames <- c("PHT", "PB", "VPA", "LEV", "LAC")
    CEbaseline <- data.frame(CEbaselinenames, CEbaselinevector)
    
    # Order by ascending CE
    CEbaseline <- CEbaseline[order(CEbaseline$CEbaselinevector), ]
    
    # Produce the text
    CEbaseline$CEbaselinenames <- as.character(CEbaseline$CEbaselinenames)
    CEbaseline$CEbaselinevector <- round(CEbaseline$CEbaselinevector, digits = 2)
    CEbaseline$CEbaselinevector <- as.character(CEbaseline$CEbaselinevector)
    finaltext <- capture.output(cat(c(CEbaseline[1, 1], ": ", CEbaseline[1, 2], ";   ",  
                                      CEbaseline[2, 1], ": ", CEbaseline[2, 2], ";   ",
                                      CEbaseline[3, 1], ": ", CEbaseline[3, 2], ";   ",
                                      CEbaseline[4, 1], ": ", CEbaseline[4, 2], ";   ",
                                      CEbaseline[5, 1], ": ", CEbaseline[5, 2]
    ),
    sep = ""))
    finaltext

  })
  
  
  
  
  
  
  ## INCREMENTAL COST EFFECTIVENESS TABLE
    output$ICER <- renderTable({
    
    # Define the values based on the inputs
    c.NoAED <- as.numeric(input$c.NoAED)
    c.PHT <- as.numeric(input$c.PHT)
    c.PB <- as.numeric(input$c.PB)
    c.VPA <- as.numeric(input$c.VPA)
    c.LEV <- as.numeric(input$c.LEV)
    c.LAC <- as.numeric(input$c.LAC)
    
    p.NoAEDSS <- as.numeric(input$p.NoAEDSS)
    p.PHTSS <- as.numeric(input$p.PHTSS)
    p.PBSS <- as.numeric(input$p.PBSS)
    p.VPASS <- as.numeric(input$p.VPASS)
    p.LEVSS <- as.numeric(input$p.LEVSS)
    p.LACSS <- as.numeric(input$p.LACSS)
  
    
    
    
    ## Utility of outcomes
    u.SS <- 1
    u.NoSS <- 0
    
    
    ## Effectiveness into the model
    e.NoAED <- (u.SS * p.NoAEDSS) + (u.NoSS * (1 - p.NoAEDSS))
    e.PHT <- (u.SS * p.PHTSS) + (u.NoSS * (1 - p.PHTSS))
    e.PB <- (u.SS * p.PBSS) + (u.NoSS * (1 - p.PBSS))
    e.VPA <- (u.SS * p.VPASS) + (u.NoSS * (1 - p.VPASS))
    e.LEV <- (u.SS * p.LEVSS) + (u.NoSS * (1 - p.LEVSS))
    e.LAC <- (u.SS * p.LACSS) + (u.NoSS * (1 - p.LACSS))

    
    
    ######FUNCTION FOR INCREMENTAL COST EFFECTIVENESS
    
    ## Create dataframe with cost and effectiveness data
    Cost <- c(c.NoAED, c.PHT, c.PB, c.VPA, c.LEV, c.LAC)
    Effectiveness <- c(e.NoAED, e.PHT, e.PB, e.VPA, e.LEV, e.LAC)
    Names <- c("No AED", "IV Phenytoin", "IV Phenobarbital", "IV Valproate", "IV Levetiracetam", "IV Lacosamide")
    rescuemeds <- data.frame(Names, Cost, Effectiveness)
    
    #Save dataframe for plot
    rescuemedsforplot <- rescuemeds
    
    rescuemeds$Cost <- as.numeric(rescuemeds$Cost)
    ## Sort by cost
    rescuemeds <- rescuemeds[order(Cost), ]
    
    
    
    ### SORT BY COST AND ELIMINATE STRONGLY DOMINATED OPTIONS    
    for (i in 1 : length(rescuemeds$Cost)) {
      
      # Calculate incremental effectiveness
      for (j in 1 : (length(rescuemeds$Cost) - 1)){
        rescuemeds$IE[1] <- rescuemeds$Effectiveness[1]
        rescuemeds$IE[j + 1] <- rescuemeds$Effectiveness[j + 1] - rescuemeds$Effectiveness[j]
      }
      
      # Identify the first row where the incremental effectiveness is negative
      firstrownegativeIE <- which (rescuemeds$IE < 0)[1]
      
      # Are there more negatives?
      nomorenegatives <- ifelse(is.na(firstrownegativeIE) == TRUE, 1, 0)
      
      
      
      if (nomorenegatives == 1) {
        break
      } else{
        ## Eliminate the first row where the incremental effectiveness is negative
        rescuemeds <- rescuemeds[- firstrownegativeIE, ]
        # Eliminate rows with NA
        rescuemeds <- rescuemeds[!is.na(rescuemeds$Names), ]
        # Renumber the rows
        rownames(rescuemeds) <- seq(length=nrow(rescuemeds))
      } 
      
    }
    # Eliminate rows with NA
    rescuemeds <- rescuemeds[!is.na(rescuemeds$Names), ]
    
    
    
    ### CALCULATE ICER AND ELIMINATE OPTIONS BY EXTENDED DOMINANCE
    for (l in 1 : length(rescuemeds$Cost)){    
      
      # Calculate incremental effectiveness
      for (j in 1 : (length(rescuemeds$Cost) - 1)){
        rescuemeds$IE[1] <- rescuemeds$Effectiveness[1]
        rescuemeds$IE[j + 1] <- rescuemeds$Effectiveness[j + 1] - rescuemeds$Effectiveness[j]
      }
      
      # Calculate incremental cost
      for (k in 1 : (length(rescuemeds$Cost) - 1)){
        rescuemeds$IC[1] <- rescuemeds$Cost[1]
        rescuemeds$IC[k + 1] <- rescuemeds$Cost[k + 1] - rescuemeds$Cost[k]
      }
      
      ## Calculate incremental cost effectiveness
      for (h in 1 : (length(rescuemeds$Cost) - 1)) {
        rescuemeds$ICER[1] <- rescuemeds$IC[1] / rescuemeds$IE[1]
        rescuemeds$ICER[h + 1] <- rescuemeds$IC[h + 1] / rescuemeds$IE[h + 1]
      }
      
      # Calculate if some ICER is higher than the next
      for (m in 1 : length(rescuemeds$Cost)) {
        rescuemeds$ICERdifference[m] <- rescuemeds$ICER[m + 1] - rescuemeds$ICER[m]
      }
      
      # Identify the first row where the incremental effectiveness is negative
      firstrownegativeICERdifference <- which (rescuemeds$ICERdifference < 0)[1]
      
      # Are there more negatives?
      nomorenegativesICERdifference <- ifelse(is.na(firstrownegativeICERdifference) == TRUE, 1, 0)
      
      
      
      if (nomorenegativesICERdifference == 1) {
        break
      } else{
        ## Eliminate the first row where the ICERdifference is negative
        rescuemeds <- rescuemeds[- firstrownegativeICERdifference, ]
        # Eliminate rows with NA
        rescuemeds <- rescuemeds[!is.na(rescuemeds$Names), ]
        # Renumber the rows
        rownames(rescuemeds) <- seq(length = nrow(rescuemeds))
      }
      
    }
    # Eliminate rows with NA
    rescuemeds <- rescuemeds[!is.na(rescuemeds$Names), ]  
    
    # Eliminate ICERdifference column
    rescuemeds <- rescuemeds[ , - 7]

    rescuemeds
  })
  
  
  
  
## PLOT  
  output$plotCE <- renderPlotly({
    
    # Define the values based on the inputs
    c.NoAED <- as.numeric(input$c.NoAED)
    c.PHT <- as.numeric(input$c.PHT)
    c.PB <- as.numeric(input$c.PB)
    c.VPA <- as.numeric(input$c.VPA)
    c.LEV <- as.numeric(input$c.LEV)
    c.LAC <- as.numeric(input$c.LAC)
    
    p.NoAEDSS <- as.numeric(input$p.NoAEDSS)
    p.PHTSS <- as.numeric(input$p.PHTSS)
    p.PBSS <- as.numeric(input$p.PBSS)
    p.VPASS <- as.numeric(input$p.VPASS)
    p.LEVSS <- as.numeric(input$p.LEVSS)
    p.LACSS <- as.numeric(input$p.LACSS)
 
    
    
    
    ## Utility of outcomes
    u.SS <- 1
    u.NoSS <- 0
    
    
    ## Effectiveness into the model
    e.NoAED <- (u.SS * p.NoAEDSS) + (u.NoSS * (1 - p.NoAEDSS))
    e.PHT <- (u.SS * p.PHTSS) + (u.NoSS * (1 - p.PHTSS))
    e.PB <- (u.SS * p.PBSS) + (u.NoSS * (1 - p.PBSS))
    e.VPA <- (u.SS * p.VPASS) + (u.NoSS * (1 - p.VPASS))
    e.LEV <- (u.SS * p.LEVSS) + (u.NoSS * (1 - p.LEVSS))
    e.LAC <- (u.SS * p.LACSS) + (u.NoSS * (1 - p.LACSS))
    
    
    ## Create dataframe with cost and effectiveness data
    Cost <- c(c.NoAED, c.PHT, c.PB, c.VPA, c.LEV, c.LAC)
    Effectiveness <- c(e.NoAED, e.PHT, e.PB, e.VPA, e.LEV, e.LAC)
    Names <- c("NoAED", "PHT", "PB", "VPA", "LEV", "LAC")
    rescuemeds <- data.frame(Names, Cost, Effectiveness)
    
    #Save dataframe for plot
    rescuemedsforplot <- rescuemeds    
    
         
    
    # Order factors
    rescuemedsforplot$Names <- factor(rescuemedsforplot$Names, levels = c("NoAED", "PHT", "PB", "VPA", "LEV", "LAC"))  # Plot CE
    plotCE <- ggplot(data = rescuemedsforplot, aes(x = Effectiveness, y = Cost, 
                                                   color = Names)) +
      geom_point(size = 5, pch = c(25, 15, 23, 17, 15, 25),
                 bg = c("NoAED"="#677719", "PHT"="#a30234", "PB"="#511c23",
                        "VPA"="#7a5071", "LEV"="#0076c0", "LAC"="#e37c1d")) +
      theme(panel.background = element_rect(fill = "white"), 
            axis.text = element_text(size = 10, color = "black", face = "bold"),
            axis.title = element_text(size = 16, color = "black", face = "bold"),
            axis.ticks.length = unit(0.2, "cm"), axis.ticks = element_line(size = 1),
            axis.line.x = element_line(color="black", size = 1),
            axis.line.y = element_line(color="black", size = 1), 
            legend.key = element_rect(fill = "white"), legend.position = "bottom") +
      scale_colour_manual(name="",  
                          values = c("NoAED"="#677719", "PHT"="#a30234", "PB"="#511c23",
                                     "VPA"="#7a5071", "LEV"="#0076c0", "LAC"="#e37c1d")) +
      labs(x= "Effectiveness (SS)", y= "Cost ($)")
    
    # Make the plot interactive
    plotCE <- ggplotly(plotCE)
    plotCE
    
  })

}



# Run the app
shinyApp(ui = ui, server = server)
